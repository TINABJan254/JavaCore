package thuc_hanh1.tong_so_gio_day;

public class MonHoc {
    private String maMH, ten;
    
    public MonHoc(String maMH, String ten){
        this.maMH = maMH;
        this.ten = ten;
    }
}
