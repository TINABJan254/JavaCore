package thuc_hanh1.tong_so_gio_day;

public class GiangVien {
    private String maGV, tenGV;
    
    public GiangVien(String maGV, String tenGV){
        this.maGV = maGV;
        this.tenGV = tenGV;
    }

    public String getTenGV() {
        return tenGV;
    }

    public String getMaGV() {
        return maGV;
    }
    
}
