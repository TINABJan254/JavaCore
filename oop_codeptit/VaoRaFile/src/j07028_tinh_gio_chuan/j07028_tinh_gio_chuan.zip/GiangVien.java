package j07028_tinh_gio_chuan;

public class GiangVien {
    private String maGV, tenGV;
    
    public GiangVien(String maGV, String tenGV){
        this.maGV = maGV;
        this.tenGV = tenGV;
    }

    public String getTenGV() {
        return tenGV;
    }

    public String getMaGV() {
        return maGV;
    }
    
}
