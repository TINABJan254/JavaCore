package j07028_tinh_gio_chuan;

public class MonHoc {
    private String maMH, ten;
    
    public MonHoc(String maMH, String ten){
        this.maMH = maMH;
        this.ten = ten;
    }
}

