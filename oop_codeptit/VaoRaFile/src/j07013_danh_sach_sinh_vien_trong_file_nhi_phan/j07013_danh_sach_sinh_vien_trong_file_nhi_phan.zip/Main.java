package j07013_danh_sach_sinh_vien_trong_file_nhi_phan;

import java.util.*;
import java.io.*;
import java.text.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        ObjectInputStream inp = new ObjectInputStream(new FileInputStream("SV.in"));
        ArrayList<SinhVien> a = (ArrayList<SinhVien>) inp.readObject();
        for (SinhVien i : a)
            System.out.println(i);
    }
}
