package j06007_bang_tinh_gio_chuan;

public class MonHoc {
    private String maMH, ten;
    
    public MonHoc(String maMH, String ten){
        this.maMH = maMH;
        this.ten = ten;
    }
    
    public String getMaMH(){
        return this.maMH;
    }
}
